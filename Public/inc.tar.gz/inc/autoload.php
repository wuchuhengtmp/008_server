<?php
// 引入系统配置文件
require_once 'config.php';
// 引入费用规则配置文件
require_once 'fee.config.php';
// 引入应用账号配置文件
require_once 'account.config.php';
// 引入会员升级规则配置文件
require_once 'user.config.php';
// 引入提现配置文件
require_once 'draw.config.php';
// 引入积分配置文件
require_once 'point.config.php';
// 引入状态配置文件
require_once 'status.php';
// 引入返回码配置文件
require_once 'code.config.php';
require_once 'extra.config.php';