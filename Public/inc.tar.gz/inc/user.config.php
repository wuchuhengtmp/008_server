<?php
/* 会员升级规则配置文件 */
//推荐注册增加经验值
define('USER_UPGRADE_REGISTER','1');
//推荐用户购物增加经验值
define('USER_UPGRADE_BUY','3');
?>