<?php
/* 账号参数配置文件 */
//淘宝客AppID
define('JD_UNIONID','[jd_unionid]');
//淘宝客App key
define('JD_AUTH_KEY','[jd_auth_key]');
//淘宝客App secret
define('ANDROID_APPKEY','[android_appkey]');
//淘宝客PID
define('ANDROID_APPSECRET','[android_appsecret]');
//淘宝客广告位ID
define('IOS_APPKEY','[ios_appkey]');
//淘宝客渠道专用PID
define('IOS_APPSECRET','[ios_appsecret]');
//维易淘宝客key
define('tb_pid','[tk_pid]');

//拼多多client_id
define('SMS_APIKEY','[sms_apikey]');
//拼多多client_secret
define('SMS_TPL','[sms_tpl]');

define('SMS_SID','[sms_sid]');
