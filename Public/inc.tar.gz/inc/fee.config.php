<?php
/* 费用规则参数配置文件 */

//直接推荐返利比例-百分比
define('REFERRER_RATE','15');
//间接推荐返利比例-百分比
define('REFERRER_RATE2','10');

//会员升级费用-1个月
define('UPGRADE_FEE_MONTH','58');
//会员升级费用-1年
define('UPGRADE_FEE_YEAR','588');
//会员升级费用-终生
define('UPGRADE_FEE_FOREVER','988');

//平台微信号
define('PLATFORM_WX','1144639594');

//分享淘宝商品网址
define('SHARE_URL','http://tkyx.taokeyun.cn');
//分享注册下载网址
define('SHARE_URL_REGISTER','http://tkyx.taokeyun.cn');
//VIP专用分享网址
define('SHARE_URL_VIP','http://tkyx.taokeyun.cn');
?>